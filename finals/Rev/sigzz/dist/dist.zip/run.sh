#!/bin/sh
./ld-linux-x86-64.so.2 --library-path . ./chal
